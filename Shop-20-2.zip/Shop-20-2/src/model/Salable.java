package model;
public interface Salable {
  public double salePrice();
}
