package model;
public interface Rentable {
  public double rentPrice(int days);
}
